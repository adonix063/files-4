

<h1 align="center">
  🌸 Commands of YuruYuri 🌸
</h1>

<p align="center">
  <img src="https://media.tenor.com/ZFlL0_gwq5QAAAAC/yuruyuri-anime.gif" alt="YuruYuri" width="300"/>
</p>

---

<p align="center">
  💖 Welcome to the official command list of <b>YuruYuri Bot</b> 💖  
  <i>A fun, cute and powerful bot inspired by the YuruYuri anime world!</i>  
</p>

---

<p align="center">
  🎀 <b>More coming soon... Stay tuned</b> 🎀
</p>

---

<p align="center">
  Made with 🩷 by <b>Ado</b>
</p>
